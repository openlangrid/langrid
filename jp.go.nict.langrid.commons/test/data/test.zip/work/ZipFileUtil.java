package jp.go.nict.langrid.commons.util.zip;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import jp.go.nict.langrid.commons.io.StreamUtil;

public class ZipFileUtil {
	public static void unzip(File zipFile, File targetDir)
	throws IOException{
		try(InputStream is = new FileInputStream(zipFile);
				ZipInputStream zis = new ZipInputStream(is)){
			ZipEntry entry = zis.getNextEntry();
			if (entry.isDirectory()) {
				new File(targetDir, entry.getName()).mkdirs();
			} else {
				File parent = new File(targetDir, entry.getName()).getParentFile();
				if (parent != null) parent.mkdirs();
				try(OutputStream os = new FileOutputStream(new File(targetDir, entry.getName()))){
					StreamUtil.transfer(zis, os);
				}
			}
		}
	}
}
